import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-reimbursement',
  templateUrl: './delete-reimbursement.component.html',
  styleUrls: ['./delete-reimbursement.component.css']
})
export class DeleteReimbursementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
