import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reimbursement-list',
  templateUrl: './reimbursement-list.component.html',
  styleUrls: ['./reimbursement-list.component.css']
})
export class ReimbursementListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
