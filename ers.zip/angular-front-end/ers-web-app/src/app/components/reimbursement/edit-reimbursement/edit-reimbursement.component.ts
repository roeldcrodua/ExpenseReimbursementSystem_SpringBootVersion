import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-reimbursement',
  templateUrl: './edit-reimbursement.component.html',
  styleUrls: ['./edit-reimbursement.component.css']
})
export class EditReimbursementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
