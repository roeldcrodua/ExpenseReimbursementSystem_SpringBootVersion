import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-reimbursement',
  templateUrl: './create-reimbursement.component.html',
  styleUrls: ['./create-reimbursement.component.css']
})
export class CreateReimbursementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
